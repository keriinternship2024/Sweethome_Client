// Home by Style Design Carousel 
$('.owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    reponsive: {
      0: {
        items: 1
      },
      600: {
        items: 3
      }
    }
  })