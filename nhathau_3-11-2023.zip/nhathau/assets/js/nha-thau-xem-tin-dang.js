$('.owl-carousel').owlCarousel({
    items: 1,
    loop: false,
    dots: false,
    URLhashListener: true,
    autoPlayHoverPause: true,
    startPosition: 'URLHash'
  })