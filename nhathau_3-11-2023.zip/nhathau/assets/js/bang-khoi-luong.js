// Popup 1
function openPopup1() {
    $(".popupForm1").show();
    $(".popup1 button").addClass("buttonStyle");
}

function closePopup1() {
    $(".popupForm1").hide();
    $(".popup1 button").removeClass("buttonStyle");
}

// Popup 2
function openPopup2() {
    $(".popupForm2").show();
    $(".popup2 button").addClass("buttonStyle");
}

function closePopup2() {
    $(".popupForm2").hide();
    $(".popup2 button").removeClass("buttonStyle");
}

// Popup 3
function openPopup3() {
    $(".popupForm3").show();
    $(".popup3 button").addClass("buttonStyle");
}

function closePopup3() {
    $(".popupForm3").hide();
    $(".popup3 button").removeClass("buttonStyle");
}

// Popup 4
function openPopup4() {
    $(".popupForm4").show();
    $(".popup4 button").addClass("buttonStyle");
}

function closePopup4() {
    $(".popupForm4").hide();
    $(".popup4 button").removeClass("buttonStyle");
}

// Popup 5
function openPopup5() {
    $(".popupForm5").show();
    $(".popup5 button").addClass("buttonStyle");
}

function closePopup5() {
    $(".popupForm5").hide();
    $(".popup5 button").removeClass("buttonStyle");
}

// Popup 6
function openPopup6() {
    $(".popupForm6").show();
    $(".popup6 button").addClass("buttonStyle");
}

function closePopup6() {
    $(".popupForm6").hide();
    $(".popup6 button").removeClass("buttonStyle");
}

// Popup 7
function openPopup7() {
    $(".popupForm7").show();
    $(".popup7 button").addClass("buttonStyle");
}

function closePopup7() {
    $(".popupForm7").hide();
    $(".popup7 button").removeClass("buttonStyle");
}

// Popup 8
function openPopup8() {
    $(".popupForm8").show();
    $(".popup8 button").addClass("buttonStyle");
}

function closePopup8() {
    $(".popupForm8").hide();
    $(".popup8 button").removeClass("buttonStyle");
}

// Popup 9
function openPopup9() {
    $(".popupForm9").show();
    $(".popup9 button").addClass("buttonStyle");
}

function closePopup9() {
    $(".popupForm9").hide();
    $(".popup9 button").removeClass("buttonStyle");
}



// More Turtorial
// Item 1
function moreTurtorial1() {
    $(".turtorial__content .item__topic.item1").addClass("item__moreStyle");
    $(".expand1").hide();
    $(".compress1").show();
}

function closeTurtorial1() {
    $(".turtorial__content .item__topic.item1").removeClass("item__moreStyle");
    $(".expand1").show();
    $(".compress1").hide();
}

// Item 2
function moreTurtorial2() {
    $(".turtorial__content .item__topic.item2").addClass("item__moreStyle");
    $(".expand2").hide();
    $(".compress2").show();
}

function closeTurtorial2() {
    $(".turtorial__content .item__topic.item2").removeClass("item__moreStyle");
    $(".expand2").show();
    $(".compress2").hide();
}

// Item 3
function moreTurtorial3() {
    $(".turtorial__content .item__topic.item3").addClass("item__moreStyle");
    $(".expand3").hide();
    $(".compress3").show();
}

function closeTurtorial3() {
    $(".turtorial__content .item__topic.item3").removeClass("item__moreStyle");
    $(".expand3").show();
    $(".compress3").hide();
}